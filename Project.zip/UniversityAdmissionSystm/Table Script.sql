CREATE TABLE users(
	login_id  VARCHAR(25) PRIMARY KEY,
	password  VARCHAR(25) NOT NULL,
	role VARCHAR(25) NOT NULL
);
INSERT INTO users VALUES('admin','admin','admin');
INSERT INTO users VALUES('mac','mac','mac');
select * from users;
commit;

create table Application(Application_id number(20), full_name varchar2(20), date_of_birth date, highest_qualification varchar2(10), marks_obtained number, goals varchar2(20), email_id varchar2(20), Scheduled_program_id varchar2(5), status varchar2(10),Date_Of_Interview date);


create table Programs_Offered  (ProgramName  varchar2(5), description varchar2(20), applicant_eligibility varchar2(40) , duration number, degree_certificate_offered varchar2(10));

create table Programs_Scheduled (Scheduled_program_id varchar2(5), ProgramName varchar2(5), Location varchar2(10), start_date date, end_date date , sessions_per_week number);

create sequence scheduled_pgm_seq start with 100;

create sequence application_id_seq start with 1000;
create table Participant( Roll_no varchar2(5), email_id varchar2(20), Application_id number , Scheduled_program_id varchar2(5));

select * from Participant;
select * from Application;
select * from Programs_Scheduled;
select * from Programs_Offered;



select * from Application;

 