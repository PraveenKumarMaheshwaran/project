package com.capgemini.uas.service;

import java.util.List;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.exception.UASException;

public interface IMACService {
	
	



	List<Application> getAllApplications(int scheduledPgmId)
			throws UASException;

	 public  boolean updateStatus(ApplicationStatus application) throws UASException;



	public ApplicationStatus getApplicationStatus(Integer applicationId)
			throws UASException;
   
	

}
