package com.capgemini.uas.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.dao.IUniversityDAO;
import com.capgemini.uas.dao.UniversityDAOImpl;
import com.capgemini.uas.exception.UASException;

public class ApplicantServiceImpl implements IApplicantService {

	@Override
	public List<ProgramsScheduled> getProgramSchedule() throws UASException {
		List<ProgramsScheduled> list = new ArrayList<>();
		IUniversityDAO univdao = new UniversityDAOImpl();
		list = univdao.getProgramSchedule();
		return list;
	}

	@Override
	public int addApplicantDetails(Application application) throws UASException {
		int applicationID = 0;
		IUniversityDAO universityDAO = null;
		universityDAO = new UniversityDAOImpl();
		applicationID = universityDAO.addApplicantDetails(application);
		return applicationID;
	}

	Logger logger = Logger.getRootLogger();
	
	@Override
	public void validateDetails(Application bean) throws UASException {
		List<String> vError = new ArrayList<String>();
		logger.info("Validating customer details");
		Pattern applName = Pattern.compile("[A-Za-z]+{20}");
		Matcher strMatch = applName.matcher(bean.getFullName());

		Pattern mailId = Pattern
				.compile("^[A-Za-z0-9\\_]{1,30}\\@[A-Za-z]{1,10}\\.[A-Za-z]{2,3}$");
		Matcher mailIDMatch = mailId.matcher(bean.getEmailID());

		Pattern marksPattern = Pattern.compile("^[6-9]{1}[0-9]{1}$");
		Matcher marksIDMatch = marksPattern.matcher(bean.getMarksObtained());

		// name
		if (!(strMatch.matches())) {

			vError.add("Name should contain alphabets only");
			logger.error("name error");

		} else if (bean.getFullName() == "") {
			logger.error(new UASException("should not be empty"));
			logger.error(" name error");
			/*
			 * throw new UASException( " Name should not be blank");
			 */
		}
		// marks
		if (!(marksIDMatch.matches())) {

			vError.add("mark should be >60");
			logger.error("marks error");

		} else if (bean.getMarksObtained() == "") {

			logger.error(" marks error");
			/*
			 * throw new UASException( "  marks should not be blank");
			 */
		}
		// mailId
		if (!(mailIDMatch.matches())) {

			vError.add("mail should be format");
			logger.error("mail error");

		} else if (bean.getEmailID() == " ") {

			logger.error(" mail error");
			/*
			 * throw new UASException( "mail id should not be blank");
			 */
		}

		if (!(vError.isEmpty())) {
			System.out.println(vError + " ");
			throw new UASException(vError + " ");
		}
		
	}

}
