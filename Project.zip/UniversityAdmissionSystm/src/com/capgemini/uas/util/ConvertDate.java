package com.capgemini.uas.util;



import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.capgemini.uas.exception.UASException;

public class ConvertDate {
	public static java.sql.Date getSqlDate(String date) throws UASException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date javaDate=new java.util.Date();
		try {
			javaDate = formatter.parse(date);
		} catch (ParseException e) {
			throw new UASException(e.getMessage());
		}
		java.sql.Date sqlDate = new Date(javaDate.getTime());

		return sqlDate;

	}
}
