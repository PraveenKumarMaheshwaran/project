package com.capgemini.uas.bean;

public class ScheduledProgramID {

	private String scheduledPgmId;
	private String scheduledPgmName;

	public String getScheduledPgmId() {
		return scheduledPgmId;
	}

	public void setScheduledPgmId(String scheduledPgmId) {
		this.scheduledPgmId = scheduledPgmId;
	}

	public String getScheduledPgmName() {
		return scheduledPgmName;
	}

	public void setScheduledPgmName(String scheduledPgmName) {
		this.scheduledPgmName = scheduledPgmName;
	}

}
