package com.capgemini.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.RetrieveAllDetails;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.bean.ScheduledProgramID;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.util.ConvertDate;
import com.capgemini.uas.util.DBConnection;

public class UniversityDAOImpl implements IUniversityDAO {

	@Override
	public List<ProgramsScheduled> getProgramSchedule() throws UASException {
		// TODO Auto-generated method stub
		List<ProgramsScheduled> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		Connection con = DBConnection.getInstance().getConnection();
		ResultSet result = null;
		try {
			pstmt = con.prepareStatement(IQueryMapper.VIEWPROGRAMSCHEDULE);
			result = pstmt.executeQuery();
			ProgramsScheduled programbean = null;
			while (result.next()) {
				programbean = new ProgramsScheduled();
				programbean.setProgramId(result.getString(1));
				programbean.setProgramName(result.getString(2));
				programbean.setLocation(result.getString(3));
				programbean.setStartDate(result.getString(4));
				programbean.setEndDate(result.getString(5));
				programbean.setSessionPerWeek(result.getString(6));
				list.add(programbean);

			}

		} catch (SQLException e) {
			throw new UASException("Error in database " + e.getMessage());
		}
		return list;
	}

	@Override
	public int addApplicantDetails(Application application)throws UASException {
		int noOfUpdates = 0;
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		Integer applicationID = 0;
		try {

			pstmt = con.prepareStatement(IQueryMapper.GETAPPIDSEQ);
			result = pstmt.executeQuery();
			while (result.next()) {
				applicationID = result.getInt("nextval");
				application.setApplicationId(applicationID.toString());
			}

			java.sql.Date dateOfBirth = ConvertDate.getSqlDate(application.getDateOfBirth());

			pstmt = con.prepareStatement(IQueryMapper.INSERTAPPLICATION);
			pstmt.setString(1, application.getApplicationId());
			pstmt.setString(2, application.getFullName());
			pstmt.setDate(3, dateOfBirth);
			pstmt.setString(4, application.getHighestQualification());
			pstmt.setString(5, application.getMarksObtained());
			pstmt.setString(6, application.getGoals());
			pstmt.setString(7, application.getEmailID());
			pstmt.setString(8, application.getScheduledProgramID());
			pstmt.setString(9, application.getStatus());
			noOfUpdates = pstmt.executeUpdate();

		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}
		if (noOfUpdates == 0) {
			throw new UASException(
					"Your request cannot be processed at this time. Please try again.");
		}
		return applicationID;
	}

	@Override
	public List<Application> getAllApplications(int scheduledPgmId)	throws UASException {
		List<Application> applicationsList = null;
		String applicationId;
		String fullName;
		String dateOfBirth;
		String highestQualification;
		String marksObtained;
		String goals;
		String emailID;
		String scheduledProgramID;
		String status;
		String dateOfInterview;
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		applicationsList = new ArrayList<Application>();
		Application application = null;
		try {
			pstmt = con.prepareStatement(IQueryMapper.GETAPPLICATIONSQUERY);
			pstmt.setInt(1, scheduledPgmId);
			result = pstmt.executeQuery();

			while (result.next()) {
				applicationId = result.getString("application_id");
				fullName = result.getString("full_name");
				dateOfBirth = result.getString("date_of_birth");
				highestQualification = result.getString("highest_qualification");
				marksObtained = result.getString("marks_obtained");
				goals = result.getString("goals");
				emailID = result.getString("email_id");
				scheduledProgramID = result.getString("scheduled_program_id");
				status = result.getString("status");
				dateOfInterview = result.getString("date_of_interview");

				application = new Application();
				application.setApplicationId(applicationId);
				application.setFullName(fullName);
				application.setDateOfBirth(dateOfBirth);
				application.setHighestQualification(highestQualification);
				application.setMarksObtained(marksObtained);
				application.setGoals(goals);
				application.setEmailID(emailID);
				application.setScheduledProgramID(scheduledProgramID);
				application.setStatus(status);
				application.setDateOfInterview(dateOfInterview);

				applicationsList.add(application);
			}

		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}

		return applicationsList;
	}

	@Override
	public boolean updateStatus(ApplicationStatus application) throws UASException {
		boolean status1=false;
		try
		{
	//	int set ;
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
	int result ;
		//java.sql.Date date = null;
	//String DateOfInterview=null;

		/*try {
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date utilDate = null;
			try {
				utilDate = formatter.parse(application.getDateOfInterview());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Date interviewDate = new Date(utilDate.getTime());*/
			//System.out.println("in dao");
			//date = ConvertDate.getSqlDate(DateOfInterview);
		
			pstmt = con.prepareStatement(IQueryMapper.UPDATESTATUS);
			
			//System.out.println("in dao");
			pstmt.setString(1, application.getStatus());
			//String date=null;
			//Scanner sc=new Scanner(System.in);
			//String date =sc.next();
			pstmt.setString(2,application.getDateOfInterview());
			pstmt.setInt(3, application.getApplicationId());
			result = pstmt.executeUpdate();
			if(result>0)
			{
				status1=true;
			}
			else
			{
				status1=false;
			}
		
			//System.out.println("in dao");
		//	while (result.next()) {
          //  String status=result.getString("status");
          //  String dateOfInterview=result.getString("date");
				/*pstmt.setString(1,"accepted");
				pstmt.setDate(2, Date);
				pstmt.setString(3, application.getApplicationId());*/
				
				
			

		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}
		
		return status1;
	}

	@Override
	public List<ScheduledProgramID> getScheduledProgramIdName()
			throws UASException {
		List<ScheduledProgramID> scheduledPgmIdList = new ArrayList<>();
		Connection con = DBConnection.getInstance().getConnection();
		String scheduledPgmId = null;
		String scheduledPgmName = null;
		ScheduledProgramID scheduledBean = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;
		try {
			pstmt = con.prepareStatement(IQueryMapper.SCHEDULEDPGMID);
			result = pstmt.executeQuery();
			while (result.next()) {
				scheduledBean = new ScheduledProgramID();
				scheduledPgmId = result.getString("scheduled_program_id");
				scheduledPgmName = result.getString("programname");
				scheduledBean.setScheduledPgmId(scheduledPgmId);
				scheduledBean.setScheduledPgmName(scheduledPgmName);
				scheduledPgmIdList.add(scheduledBean);
			}
		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}

		return scheduledPgmIdList;
	}

	@Override
	public ApplicationStatus getApplicationStatus(Integer applicationId)
			throws UASException {

		PreparedStatement pstmt = null;
		ApplicationStatus appbean = null;
		Connection con = DBConnection.getInstance().getConnection();
		ResultSet result = null;

		try {

			pstmt = con.prepareStatement(IQueryMapper.VIEWAPPLICATIONSTATUS);
			pstmt.setInt(1, applicationId);
			result = pstmt.executeQuery();

			if (result.next()) {
				appbean = new ApplicationStatus();
				appbean.setApplicationId(applicationId);
				appbean.setFullName(result.getString("full_name"));
				appbean.setDateOfBirth(result.getString("date_of_birth"));
				appbean.setHighestQualification(result.getString("highest_qualification"));
				appbean.setMarksObtained(result.getString("marks_obtained"));
				appbean.setGoals(result.getString("goals"));
				appbean.setEmailId(result.getString("email_id"));
				appbean.setScheduledProgramId(result.getString("scheduled_program_id"));
				appbean.setStatus(result.getString("status"));
				appbean.setDateOfInterview(result.getString("date_of_interview"));

			}
		} catch (SQLException exp) {
			exp.printStackTrace();

		}
		return appbean;
	}

	@Override
	public List<ProgramsOffered> getProgramsOffered() throws UASException {
		List<ProgramsOffered> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		Connection con = DBConnection.getInstance().getConnection();
		ResultSet result = null;
		try {
			pstmt = con.prepareStatement(IQueryMapper.VIEWPGMSOFFERED);
			result = pstmt.executeQuery();
			ProgramsOffered programbean = null;
			while (result.next()) {
				programbean = new ProgramsOffered();
				programbean.setProgramName(result.getString("programname"));
				programbean.setDescription(result.getString("description"));
				programbean.setApplicantEligibility(result.getString("applicant_eligibility"));
				programbean.setDuration(result.getString("duration"));
				programbean.setDegreeCertificate(result.getString("degree_certificate_offered"));
				list.add(programbean);

			}

		} catch (SQLException e) {
			throw new UASException("error in database " + e.getMessage());
		}
		return list;

	}

	@Override
	public List<ProgramsScheduled> getProgramScheduledByDate(
			String startDate, String endDate) throws UASException {
		List<ProgramsScheduled> scheduledPgmScheduledList = new ArrayList<>();
		Connection con = DBConnection.getInstance().getConnection();
		String scheduledPgmId = null;
		String scheduledPgmName = null;
		String scheduledPgmLocation = null;
		String scheduledPgmStDate = null;
		String scheduledPgmEnDate = null;
		String sessionsPerWeek = null;
		ProgramsScheduled scheduledBean = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;
		java.sql.Date sqlStartDate = null;
		java.sql.Date sqlEndDate = null;

		try {
			sqlStartDate = ConvertDate.getSqlDate(startDate);
			sqlEndDate = ConvertDate.getSqlDate(endDate);
	       
			pstmt = con.prepareStatement(IQueryMapper.PROGRAMSCHEDULEDBYDATE);
			  pstmt.setDate(1, sqlStartDate);
				
				pstmt.setDate(2, sqlEndDate);
		
			
			result = pstmt.executeQuery();
			
			while(result.next()) {
				
				scheduledBean = new ProgramsScheduled();
				scheduledPgmId = result.getString("scheduled_program_id");
				scheduledPgmName = result.getString("programname");
				scheduledPgmLocation = result.getString("location");
				scheduledPgmStDate = result.getString("start_date");
				scheduledPgmEnDate = result.getString("end_date");
				sessionsPerWeek = result.getString("sessions_per_week");

				scheduledBean.setProgramId(scheduledPgmId);
				scheduledBean.setProgramName(scheduledPgmName);
				scheduledBean.setLocation(scheduledPgmLocation);
				scheduledBean.setStartDate(startDate);
				scheduledBean.setEndDate(scheduledPgmEnDate);
				scheduledBean.setSessionPerWeek(sessionsPerWeek);
				scheduledPgmScheduledList.add(scheduledBean);
				
				
			}
		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}
		return scheduledPgmScheduledList;
	}

	@Override
	public int deleteScheduledPgm(String pgmId) throws UASException {
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		int noOfDeletes = 0;

		try {
			pstmt = con.prepareStatement(IQueryMapper.DELETEPROGRAMSCHEDULED);
			pstmt.setString(1, pgmId);

			noOfDeletes = pstmt.executeUpdate();
			System.out.println(noOfDeletes);
		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}

		return noOfDeletes;
	}

	@Override
	public int deleteOfferedProgram(String programName) throws UASException {
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		int noOfDeletes = 0;

		try {
			pstmt = con.prepareStatement(IQueryMapper.DELETEPROGRAMOFFERED);
			pstmt.setString(1, programName);
			noOfDeletes = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return noOfDeletes;
	}

	@Override
	public int updateProgramsOffered(ProgramsOffered programsOffered)
			throws UASException {
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		int noOfUpdates = 0;
		try {
			pstmt = con.prepareStatement(IQueryMapper.UPDATEPROGRAMSOFFERED);

			pstmt.setString(1, programsOffered.getDescription());
			pstmt.setString(2, programsOffered.getApplicantEligibility());
			pstmt.setString(3, programsOffered.getProgramName());
			noOfUpdates = pstmt.executeUpdate();
			// System.out.println("hello");

		} catch (SQLException e) {
			throw new UASException(
					"We are unable to process your request at this time. Please try again. "
							+ e.getMessage());
		}

		return noOfUpdates;
	}

	@Override
	public int addToSchedule(ProgramsScheduled scheduledBean)
			throws UASException {
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		int noOfUpdates = 0;
		try {

			java.sql.Date startDate = ConvertDate.getSqlDate(scheduledBean
					.getStartDate());
			java.sql.Date endDate = ConvertDate.getSqlDate(scheduledBean
					.getEndDate());

			pstmt = con.prepareStatement(IQueryMapper.ADDTOSCHEDULE);
			pstmt.setString(1, scheduledBean.getProgramName());
			pstmt.setString(2, scheduledBean.getLocation());
			pstmt.setDate(3, startDate);
			pstmt.setDate(4, endDate);
			pstmt.setString(5, scheduledBean.getSessionPerWeek());

			noOfUpdates = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return noOfUpdates;
	}

	@Override
	public List<RetrieveAllDetails> getProgramDetails() throws UASException {

		List<RetrieveAllDetails> getlist = null;

		String programName1;
		String description;
		String applicantEligibility;
		String duration;
		String degreeCertificate;
		String programId;
		String location;
		String startDate;
		String endDate;
		String sessionPerWeek;

		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		ResultSet result = null;

		getlist = new ArrayList<RetrieveAllDetails>();
		RetrieveAllDetails get = null;

		try {
			pstmt = con.prepareStatement(IQueryMapper.GETALLDETAILS);
			result = pstmt.executeQuery();
			while (result.next()) {
				programName1 = result.getString("programname");
				location = result.getString("location");
				startDate = result.getString("start_date");
				endDate = result.getString("end_date");
				sessionPerWeek = result.getString("sessions_Per_Week");
				description = result.getString("description");
				applicantEligibility = result
						.getString("applicant_eligibility");
				duration = result.getString("duration");
				degreeCertificate = result
						.getString("degree_certificate_offered");

				get = new RetrieveAllDetails();
				get.setDescription(description);
				get.setApplicantEligibility(applicantEligibility);

				get.setDuration(duration);
				get.setDegreeCertificate(degreeCertificate);
				get.setLocation(location);
				get.setStartDate(startDate);
				get.setEndDate(endDate);
				get.setSessionPerWeek(sessionPerWeek);
				get.setProgramName(programName1);
				getlist.add(get);

			}

		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}

		return getlist;
	}

	@Override
	public int addToOffered(ProgramsOffered offeredBean)
			throws UASException {
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		int noOfUpdates = 0;
		try {
			pstmt = con.prepareStatement(IQueryMapper.ADDTOOFFERED);

			pstmt.setString(1, offeredBean.getProgramName());
			pstmt.setString(2, offeredBean.getDescription());
			pstmt.setString(3, offeredBean.getApplicantEligibility());
			pstmt.setString(4, offeredBean.getDuration());
			pstmt.setString(5, offeredBean.getDegreeCertificate());
			noOfUpdates = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new UASException(e.getMessage());
		}

		return noOfUpdates;
	}

	
		
	}


