package com.cg.uas.ui;


import java.io.BufferedReader;


import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.uas.service.IService;
//import com.capgemini.uas.service.ServiceImpl;

public class MainPage {
	public static void main(String[] args) {

		PropertyConfigurator.configure("resource/log4j.properties");

		String ch;
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("********University Admission System********");
			System.out.println("                                            ");
			System.out.println("-------------------Welcome!----------------");
			System.out.println("                                            ");
			System.out.println(" 1 To Select Applicant Option");
			System.out.println("                                            ");
			System.out.println(" 2 To Login(Admin,MAC)");
			System.out.println("                                            ");
			System.out.println(" 3 To Exit");
			System.out.println("                                            ");
			System.out.println("-------------------------------------------");

			ch = sc.next();

			switch (ch) {
			case "1":
				
				//Calling Application Console
				ApplicantConsole applicant = new ApplicantConsole();
				applicant.getApplicant();
				break;
			case "2":
				
				//Calling Login console
				LoginConsole login = new LoginConsole();
				login.getLoginDetails();
				break;
			case "3":
				
				//Exit
				System.out.println("Thankyou for using UAS Application!! "
						+ "");
				System.exit(0);
				break;

			default:
				System.out.println("Please enter a valid choice");
			}

		} while (ch != "3");
	}
}
