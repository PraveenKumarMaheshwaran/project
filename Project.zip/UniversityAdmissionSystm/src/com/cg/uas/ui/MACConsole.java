package com.cg.uas.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.AdminServiceImpl;
import com.capgemini.uas.service.IMACService;
import com.capgemini.uas.service.MACServiceImpl;

public class MACConsole {
	static BufferedReader br = new BufferedReader(new InputStreamReader(
			System.in));
	static IMACService service = new MACServiceImpl();
	static Scanner sc = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	@SuppressWarnings("unused")
	public void getMac() {
		PropertyConfigurator.configure("resource//log4j.properties");
		int applicationId;
		int programId;
		String ScheduledProgramId;
		String programName;
		ProgramsOffered offeredBean = null;
		ApplicationStatus statusBean = null;
		ApplicationStatus application = null;
		ProgramsScheduled scheduledBean = null;
		boolean set =true;
		int option = 0;
		int choice = 0;
		int x = 0;
	
		String up =null;

		do {
			System.out.println("--------------------------------------------");
			System.out.println("1 : View Applications for specific program");
			System.out.println("                                            ");
			System.out.println("2 : Accept/reject applications ");
			System.out.println("                                            ");
			System.out.println("3 : Logout");
			System.out.println("                                            ");
			System.out.println("--------------------------------------------");
			x = sc.nextInt();
			switch (x) {
			case 1:
				printApplications();
				break;
			case 2:
				System.out.println("Enter the application id to be accepted : ");
				int appNo = sc.nextInt();
				String status = "accepted";
				ApplicationStatus bean = new ApplicationStatus();
				IMACService service = new MACServiceImpl();
				try {
					bean = service.getApplicationStatus(appNo);
				 
				System.out.println("Status is " + bean.getStatus());
				//System.out.println("Status is " + bean.getFullName());
				System.out.println("To modify status ");
				
						System.out.println ( 1+" :change the status to accept");
						System.out.println (   2+": change the status to rejected");
					
				
				//System.out.println(first);
				
				up = sc.next();
				if (up.equals("1")) {
					System.out.println("Enter the Interview date in format ex (23-sep-2018)");
					// String date = sc.next();
					// bean.setDateOfInterview(date);
					// MACServiceImpl admin1=new   MACServiceImpl();
					// admin1.updateStatus(application);
					// Date dateOfInterview = sc.nex
                   // System.out.println("Your Status "+status);
				}
				else
				{
					
					String	status1="Rejected";
					bean.setStatus(status1);
					String date=null;
					// String date = sc.next();
					bean.setDateOfInterview(date);
					
					  MACServiceImpl admin1=new   MACServiceImpl();
					  boolean set1;
						
						set1 = admin1.updateStatus(bean);
						if(set1 == true)
						{
							System.out.println("\n Request Rejected");
						}
						else
						{
							System.out.println("\n Not successfully");
						}
					//set = admin1.updateStatus(bean);
					
				}
				
			
			/*	if(set == true)
				{
					 System.out.println("Your Status Rejected ");	
				}else
				{
					System.out.println("Your status is not valid ");
				}
					 */
				/*else
				{
					System.out.println("Please select valid one");
					break;
				}*/
					//System.out.println("Enter the Interview date ");

					// DateTimeFormatter formatter =
					// DateTimeFormatter.ofPattern("dd/MM/yyyy");
					// System.out
					// .println("Enter the date in this format : dd/MM/yyyy");
				   String date = sc.next();
				//	System.out.println("in main");
					

					// SimpleDateFormat dateFormat = new
					// SimpleDateFormat("dd-MMM-yyyy");
					// 01 NOVEMBER 2012
					// LocalDate date = LocalDate.parse(dateOfInterview,
					// formatter);
					// java.sql.Date sqlDate = java.sql.Date.valueOf(date);
					// bean.setStatus(status);
					//Application bean1 = new Application();
				   MACServiceImpl admin=new   MACServiceImpl();
				   String	status2="accepted";
					bean.setStatus(status2);
					
					bean.setDateOfInterview(date);
					
					//int statusNew;
					boolean set1;
					
						set1 = admin.updateStatus(bean);
					
					if(set1 == true)
					{
						System.out.println("\n Request Accepted");
					}
					else
					{
						System.out.println("\nNot Updated successfully");
					}
				}
					
					catch (UASException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					/*try {
						System.out.println("in main1");
						statusNew = service.updateStatus(bean1);
						
						if (statusNew != 0) {
							System.out.println("New status" + bean1.getStatus());
						} else {
							System.out.println("Status returning 0 value");
						}*/
				/*	} catch (UASException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
*/
			
		
				break;
		
			case 3:
				break;
			default:
				System.out.println("Enter valid choice");

			}
		} while (x != 3);
		

	}

	private static void printApplications() {

		System.out.println("Enter the scheduled program id  : ");
		int scheduledPgmId = sc.nextInt();
		List<Application> aList = new ArrayList<>();
		IMACService service1 = new MACServiceImpl();
		try {
			aList = service1.getAllApplications(scheduledPgmId);
		} catch (UASException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		System.out.println("Printing applications for program_id "+ scheduledPgmId);
		for (int j = 0; j < aList.size(); j++) {

			System.out.println("Application No : " + (j + 1));
			System.out.println("Application Id : " + aList.get(j).getApplicationId());
			
			System.out.println("Full Name : " + aList.get(j).getFullName());
			
			System.out.println("Date of birth : "+ aList.get(j).getDateOfBirth());
		
			System.out.println("Date of Interview : "+ aList.get(j).getDateOfInterview());

			System.out.println("Email Id" + aList.get(j).getEmailID());
		
			System.out.println("Goals : " + aList.get(j).getGoals());
	
			System.out.println("Status : " + aList.get(j).getStatus());
		
			System.out.println("Qualification : "
					+ aList.get(j).getHighestQualification());
		
			System.out.println("\n");
		}

	}
}
