package com.cg.uas.ui;

import java.io.BufferedReader;



import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IService;
import com.capgemini.uas.service.IMACService;
import com.capgemini.uas.service.IAdminService;
//import com.capgemini.uas.service.ServiceImpl;
import com.capgemini.uas.service.MACServiceImpl;
import com.capgemini.uas.service.AdminServiceImpl;

public class AdminConsole {
	static BufferedReader br = new BufferedReader(new InputStreamReader(
			System.in));
	//static IService service = new ServiceImpl();
	static IAdminService adminservice = new AdminServiceImpl();
	static Scanner sc = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	public void getAdminFunction() {
		int applicationId;
		int programId;
		String ScheduledProgramId;
		String programName;
		ProgramsOffered offeredBean = null;
		ApplicationStatus statusBean = null;
		Application application = null;
		ProgramsScheduled scheduledBean = null;

		int option = 0;
		int choice = 0;
		do {
			System.out.println("-----------------------------------------");
			System.out.println(" 1 To Update Scheduled Program");
			System.out.println("                                            ");
			System.out.println(" 2 To Update Program Offered");
			System.out.println("                                            ");
			System.out.println(" 3 To Generate Reports");
			System.out.println("                                            ");
			System.out.println(" 4 to Logout");
			System.out.println("                                            ");
			System.out.println("-----------------------------------------");

			try {
				choice = sc.nextInt();
				switch (choice) {

				case 1:
					do {
						System.out.println("-----------------------------------------");
						System.out.println(" 1 to Add program");
						System.out.println("                                            ");
						System.out.println(" 2 to Delete program");
						System.out.println("                                            ");
						System.out.println(" 3 to go to admin main");
						System.out.println("                                            ");
						System.out.println("-----------------------------------------");

						try {

							choice = sc.nextInt();

							switch (choice) {
				//Inserting Details In Scheduled Program
							case 1:
								System.out.println("-----------------------------------------");
								System.out.println("Enter The Details To Apply ");
								while (scheduledBean == null) {
									try
									{
										scheduledBean = populateAddScheduledProgram();
										adminservice.validatePrograms(scheduledBean);
										programId = adminservice.addToSchedule(scheduledBean);
										System.out.println("-----------------------------------------");
										System.out.println("New Program details has been successfully registered ");
										System.out.println("-----------------------------------------");
									} 
									catch (IOException e) {
										e.printStackTrace();
									} 
									catch (UASException e) {
										e.printStackTrace();
									}

								}
								break;
					//Deleting Scheduled Program 
							case 2:
								System.out.println("Enter The Program Id to Delete Scheduled Program: ");
								ScheduledProgramId = sc.next();

								int deleteCheck = adminservice.deleteScheduledPgm(ScheduledProgramId);

								if (deleteCheck == 1)
								{
									System.out.println("-----------------------------------------");
									System.out.println("!!Program Deleted successfully!!");
									System.out.println("-----------------------------------------");
								} else 
								{
									System.out.println("-----------------------------------------");
									System.out.println("Kindly Enter A Valid Input");
									System.out.println("-----------------------------------------");
								}
								break;
							case 3:
								break;
							default:
								System.out.println("please enter a valid choice");
							}

						} catch (InputMismatchException e) {
							sc.nextLine();
							System.err.println("Please enter a numeric value, try again");
						} catch (UASException e) {
							e.printStackTrace();
						}
					} while (choice != 3);

					break;

				case 2:
					
					do {
						System.out.println("-----------------------------------------");
						System.out.println(" 1 to Add program");
						System.out.println("                                            ");
						System.out.println(" 2 to Delete program");
						System.out.println("                                            ");
						System.out.println(" 3 to Update program");
						System.out.println("                                            ");
						System.out.println(" 0 to GO Back Admin Main");
						System.out.println("                                            ");
						System.out.println("-----------------------------------------");

						try {
							choice = sc.nextInt();

							switch (choice) {
						
					//Inserting Details Into Program Offered
							case 1:

								System.out.println("Enter The Details");
								offeredBean = populateAddProgramOffredDetails();
								int check = adminservice.addToOffered(offeredBean);
								if (check == 1) {
									System.out.println("-----------------------------------------");
									System.out.println("Program Offered Added Successsfully ");
									System.out.println("-----------------------------------------");
								} else {
									System.out.println("-----------------------------------------");
									System.out.println("Enter Correct Details ");
									System.out.println("-----------------------------------------");
								}

								break;
					//Deleting Program Offered Details
							case 2:
								System.out.println("-----------------------------------------");
								System.out.println("Enter The Program Name : ");
								programName = sc.next();
								int checkDelete = adminservice.deleteOfferedProgram(programName);

								if (checkDelete == 1) {
									System.out.println("-----------------------------------------");
									System.out.println("Program Deleted successfully!!");
									System.out.println("-----------------------------------------");
								} else {
									System.out.println("-----------------------------------------");
									System.out.println("Enter A Valid Input(Name)");
									System.out.println("-----------------------------------------");
								}
								break;

					//Updating Program Offered Details 
							case 3:

								offeredBean = populateUpdateProgramOffredDetails();
								int checkUpdate = adminservice.updateProgramsOffered(offeredBean);
								if (checkUpdate == 1) {
									System.out.println("-----------------------------------------");
									System.out.println("!!Program Updated successfully!!");
									System.out.println("-----------------------------------------");
								} else {
									System.out.println("-----------------------------------------");
									System.out.println("!!NOT Updated..Please Give the Correct Input");
									System.out.println("-----------------------------------------");
								}
								break;
								
							case 0:
								break;
							default:
								System.out.println("-----------------------------------------");
								System.out.println("Please enter a valid choice");
								System.out.println("-----------------------------------------");
							}
							

						} catch (InputMismatchException e) {
							sc.nextLine();
							System.out.println("-----------------------------------------");
							System.err.println("Please enter a numeric value, try again");
							System.out.println("-----------------------------------------");
						} catch (IOException e) {

							e.printStackTrace();
						} catch (UASException e) {

							e.printStackTrace();
						}
					} while (choice != 0);
					break;

				case 3:
					do {
						System.out.println("-----------------------------------------");
						System.out.println(" 1 To View list of programs scheduled to commence in a given time period ");
						System.out.println("                                            ");
						System.out.println(" 2 To View List of applicants for a scheduled program.");
						System.out.println("                                            ");
						System.out.println(" 3 to go to admin main");
						System.out.println("                                            ");
						System.out.println("-----------------------------------------");

						try {

							choice = sc.nextInt();

							switch (choice) {
			//Printing Program Offered List In Specific Date 
							case 1:
								System.out.println("Enter The Time Period ");
								System.out.println("Enter Start Date(DD-MM-YYYY) ");
								String startDate = sc.next();
								System.out.println("Enter End Date(DD-MM-YYYY) ");
								String endDate = sc.next();

								try {
									List<ProgramsScheduled> scheduledList = new ArrayList<>();
									scheduledList = adminservice.getProgramScheduledByDate(startDate, endDate);
									/*Iterator<ProgramsScheduled> i = scheduledList.iterator();
									while (i.hasNext())
									{
										System.out.println(i.next());
									}*/
									for(ProgramsScheduled ps: scheduledList){
										String id=ps.getProgramId();
										System.out.println("id:"+id);
										String program=ps.getProgramName();
										System.out.println("program name:"+program);
										String location=ps.getLocation();
										System.out.println("location:"+location);
										String session=ps.getSessionPerWeek();
										System.out.println("session per week:"+session);
									}
								} 
								catch (UASException e)
								{
									System.out.println("Error  :"+ e.getMessage());
								}
								break;
							case 2:
								printApplications();
								break;
								
							case 3:
								break;
							default:
								System.out.println("Enter a valid choice");
								}

						} catch (InputMismatchException e) {
							sc.nextLine();
							System.err.println("Please enter a numeric value, try again");
						}

					} while (choice != 3);

				}
			} catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		} while (choice != 4);
	}

	//Populate Function to Add Program Offered Details
	
	private static ProgramsOffered populateAddProgramOffredDetails()
			throws IOException, UASException {

		ProgramsOffered offeredBean = new ProgramsOffered();

		System.out.println("Enter Program Name: ");
		offeredBean.setProgramName(br.readLine());

		System.out.println("Enter Description: ");
		offeredBean.setDescription(br.readLine());

		System.out.println("Enter Applicant Eligibility: ");
		offeredBean.setApplicantEligibility(br.readLine());

		System.out.println("Enter Duration: ");
		offeredBean.setDuration(br.readLine());

		System.out.println("Enter Degree Certificate: ");
		offeredBean.setDegreeCertificate(br.readLine());
		return offeredBean;
	}

	//Populate function Add Scheduled Program Details
	
	private static ProgramsScheduled populateAddScheduledProgram()
			throws IOException, UASException {
		ProgramsScheduled scheduledBean = new ProgramsScheduled();
		System.out.println("Enter the Details Of Add Scheduled Program: ");

		System.out.println("Enter Program Name: ");
		scheduledBean.setProgramName(br.readLine());

		System.out.println("Enter Location");
		scheduledBean.setLocation(br.readLine());

		System.out.println("Enter Start Date(DD-MM-YYYY): ");
		scheduledBean.setStartDate(br.readLine());

		System.out.println("Enter End Date(DD-MM-YYYY): ");
		scheduledBean.setEndDate(br.readLine());

		System.out
				.println("Enter Sessions Per Weeks(sessions should be <30): ");
		scheduledBean.setSessionPerWeek(br.readLine());
		return scheduledBean;
	}

	//Populate Function Update Program Offered To Update Details 
	
	private static ProgramsOffered populateUpdateProgramOffredDetails()
			throws IOException, UASException {
		ProgramsOffered offeredBean = new ProgramsOffered();

		System.out.println("Enter Program Name: ");
		offeredBean.setProgramName(br.readLine());

		System.out.println("Enter Discription To Update: ");
		offeredBean.setDescription(br.readLine());

		System.out.println("Enter Applicant Eligibility: ");
		offeredBean.setApplicantEligibility(br.readLine());
		return offeredBean;
	}

	//printing Applicant Details For Specific Scheduled Program Id
	private static void printApplications() {

		System.out.println("Enter the scheduled program id  : ");
		int scheduledPgmId = sc.nextInt();
		List<Application> aList = new ArrayList<>();
		IMACService service1 = new MACServiceImpl();
		try {
			aList = service1.getAllApplications(scheduledPgmId);
		} catch (UASException e) {
			
			e.printStackTrace();
		}


		System.out.println("Printing applications for program_id "
				+ scheduledPgmId);
		for (int j = 0; j < aList.size(); j++) {

			System.out.println("Application No : " + (j + 1));
			System.out.println("Application Id : "
					+ aList.get(j).getApplicationId());
			
			System.out.println("Full Name : " + aList.get(j).getFullName());
		
			System.out.println("Date of birth : "
					+ aList.get(j).getDateOfBirth());
			
			System.out.println("Date of Interview : "
					+ aList.get(j).getDateOfInterview());
			
			System.out.println("Email Id" + aList.get(j).getEmailID());
		
			System.out.println("Goals : " + aList.get(j).getGoals());
			
			System.out.println("Status : " + aList.get(j).getStatus());
		
			System.out.println("Qualification : "
					+ aList.get(j).getHighestQualification());
		
			System.out.println("\n");
		}

	}
}
